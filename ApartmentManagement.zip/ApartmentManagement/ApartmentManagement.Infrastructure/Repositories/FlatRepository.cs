﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApartmentManagement.Domain.Context;
using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using BookStore.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;

namespace ApartmentManagement.Infrastructure.Repositories
{
    public class FlatRepository : Repository<Flat>, IFlatRepository
    {
        public FlatRepository(AppDbContext context) : base(context) { }

        public override async Task<List<Flat>> GetAll()
        {
            return await Db.Flats.AsNoTracking().OrderBy(b => b.FlatNo)
                .ToListAsync();
        }

        public override async Task<Flat> GetById(int id)
        {
            return await Db.Flats.AsNoTracking()
                .Where(b => b.Id == id)
                .FirstOrDefaultAsync();
        }

        //public async Task<IEnumerable<Book>> GetBooksByCategory(int categoryId)
        //{
        //    return await Search(b => b.CategoryId == categoryId);
        //}

        //public async Task<IEnumerable<Book>> SearchBookWithCategory(string searchedValue)
        //{
        //    return await Db.Books.AsNoTracking()
        //        .Include(b => b.Category)
        //        .Where(b => b.Name.Contains(searchedValue) || 
        //                    b.Author.Contains(searchedValue) ||
        //                    b.Description.Contains(searchedValue) ||
        //                    b.Category.Name.Contains(searchedValue))
        //        .ToListAsync();
        //}
    }
}