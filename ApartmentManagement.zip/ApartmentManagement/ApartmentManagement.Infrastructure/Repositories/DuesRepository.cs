﻿using ApartmentManagement.Domain.Context;
using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using BookStore.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Infrastructure.Repositories
{
    public class DuesRepository: Repository<Dues>, IDuesRepository
    {
        public DuesRepository(AppDbContext context) : base(context) { }

      
    }
}
