﻿using ApartmentManagement.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Context
{

    public static class ContextSeed
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new AppDbContext(serviceProvider.GetRequiredService<DbContextOptions<AppDbContext>>()))
            {
                if (context.Users.Any())
                {
                    return;
                }

                context.Users.AddRange(
                   new User {Name = "Merve", SurName = "Bakır", UserName = "admin", Email = "merven.bkr@gmail.com", Password = "1234", Role = "Admin" },
                   new User { Name = "Merve", SurName = "Bakır", UserName = "user", Email = "merven.bkr@gmail.com", Password = "1234", Role = "user" });

                context.SaveChanges();
            }
        }
    }
}
