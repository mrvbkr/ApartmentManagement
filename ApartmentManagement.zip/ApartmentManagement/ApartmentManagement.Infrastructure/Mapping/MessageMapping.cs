﻿using ApartmentManagement.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Infrastructure.Mapping
{
    public class MessageMapping : IEntityTypeConfiguration<Message>
    {
        public void Configure(EntityTypeBuilder<Message> builder)
        {
            builder.HasKey(b => b.Id);

            builder.Property(b => b.MessageText)
                .IsRequired();


            builder.Property(b => b.MessageFrom)
                .IsRequired(false);

            builder.Property(b => b.MessageTo)
                .IsRequired(false);

            builder.ToTable("Messages");
        }
    }
}
