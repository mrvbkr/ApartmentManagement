﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApartmentManagement.Domain.Models;

namespace ApartmentManagement.Infrastructure.Mapping
{
    public class FlatMapping : IEntityTypeConfiguration<Flat>
    {
        public void Configure(EntityTypeBuilder<Flat> builder)
        {
            builder.HasKey(b => b.Id);

            builder.Property(b => b.FlatNo)
                .IsRequired()
                .HasColumnType("int");

            builder.Property(b => b.FloorNo)
                .IsRequired()
                .HasColumnType("int");

            builder.Property(b => b.Blok)
                .IsRequired()
                .HasColumnType("varchar(350)");

            builder.Property(b => b.Type)
                .IsRequired(false);

            builder.Property(b => b.Situation)
                .IsRequired();

            builder.Property(b => b.UserId)
                .IsRequired(false);

            builder.ToTable("Flats");
        }
    }
}
