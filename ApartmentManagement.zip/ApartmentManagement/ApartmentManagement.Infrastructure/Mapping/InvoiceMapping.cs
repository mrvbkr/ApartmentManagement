﻿using ApartmentManagement.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Infrastructure.Mapping
{
    public class InvoiceMapping : IEntityTypeConfiguration<Invoice>
    {
        public void Configure(EntityTypeBuilder<Invoice> builder)
        {
            builder.HasKey(b => b.Id);

            builder.Property(b => b.Amount)
                .IsRequired();


            builder.Property(b => b.Situation)
                .IsRequired();

            builder.Property(b => b.PeriodMonth)
                .IsRequired();


            builder.Property(b => b.PeriodYear)
                .IsRequired();

            builder.Property(b => b.UserId)
                .IsRequired(false);

            builder.Property(b => b.FlatId)
                .IsRequired(false);

            builder.ToTable("Invoices");
        }
    }
}
