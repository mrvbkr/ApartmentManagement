﻿using ApartmentManagement.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Infrastructure.Mapping
{
    public class PaymentMapping : IEntityTypeConfiguration<Payment>
    {
        public void Configure(EntityTypeBuilder<Payment> builder)
        {
            builder.HasKey(b => b.Id);

            builder.Property(b => b.Amount)
                .IsRequired();

            builder.Property(b => b.Date)
                .IsRequired();

            builder.Property(b => b.UserId)
                .IsRequired(false);

            builder.Property(b => b.DuesId)
             .IsRequired(false);

            builder.Property(b => b.InvoiceId)
          .IsRequired(false);

            builder.ToTable("Payments");
        }
    }
}
