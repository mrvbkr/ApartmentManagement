﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Models
{
    public class Flat : Entity
    {
       
        public int FlatNo { get; set; }
        public bool Situation { get; set; } //empty or full
        public char Blok { get; set; }
        public int FloorNo { get; set; }
        public string Type { get; set; }
        public int? UserId { get; set; }

        /* EF Relation */
        public User? User { get; set; }
    }
}
