﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Models
{
    public class Payment:Entity
    {
        public double Amount { get; set; }
        public int Type { get; set; } // Invoice or Dues
        public DateTime Date { get; set; }
        public int UserId { get; set; }
        public int DuesId { get; set; }
        public int InvoiceId { get; set; }

        /* EF Relation */
        public User User { get; set; }
        public Dues Dues { get; set; }
        public Invoice Invoice { get; set; }
    }
}
