﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Models
{
    public class Invoice:Entity
    {
        public double Amount { get; set; }
        public bool Situation { get; set; } // paid or not paid
        public int PeriodMonth { get; set; }
        public int PeriodYear { get; set; }
        public int UserId { get; set; }
        public int FlatId { get; set; }

        /* EF Relation */
        public User User { get; set; }
        public Flat Flat { get; set; }
    }
}
