﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Models
{
    public class Message:Entity
    {
        public string MessageText { get; set; }
        public int MessageFrom { get; set; }
        public int MessageTo { get; set; }

        /* EF Relation */
        public User User { get; set; }

    }
}
