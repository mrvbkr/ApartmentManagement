﻿using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Services
{
    public class DuesService : IDuesService
    {
        private readonly IDuesRepository _DuesRepository;

        public DuesService(IDuesRepository DuesRepository)
        {
            _DuesRepository = DuesRepository;

        }

        public async Task<IEnumerable<Dues>> GetAll()
        {
            return await _DuesRepository.GetAll();
        }

        public async Task<Dues> GetById(int id)
        {
            return await _DuesRepository.GetById(id);
        }

        public async Task<Dues> Add(Dues dues)
        {
            await _DuesRepository.Add(dues);
            return dues;
        }

        public async Task<Dues> Update(Dues dues)
        {
            await _DuesRepository.Update(dues);
            return dues;
        }

        public async Task<bool> Remove(Dues dues)
        {
            //var books = await _bookService.GetBooksByCategory(category.Id);
            //if (books.Any()) return false;

            await _DuesRepository.Remove(dues);
            return true;
        }


        public void Dispose()
        {
            _DuesRepository?.Dispose();
        }


        Task<IEnumerable<Dues>> IDuesService.GetDuesByUser(int flatId)
        {
            throw new NotImplementedException();
        }

    }
}
