﻿using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Services
{
    public class FlatService:IFlatService
    {
        private readonly IFlatRepository _flatRepository;
       

        public FlatService(IFlatRepository flatRepository)
        {
            _flatRepository = flatRepository;
        }

        public async Task<IEnumerable<Flat>> GetAll()
        {
            return await _flatRepository.GetAll();
        }

        public async Task<Flat> GetById(int id)
        {
            return await _flatRepository.GetById(id);
        }

        public async Task<Flat> Add(Flat flat)
        {
            if (_flatRepository.Search(c => c.FlatNo == flat.FlatNo).Result.Any())
                return null;

            await _flatRepository.Add(flat);
            return flat;
        }

        public async Task<Flat> Update(Flat flat)
        {
            if (_flatRepository.Search(c => c.FlatNo == flat.FlatNo && c.Id != flat.Id).Result.Any())
                return null;

            await _flatRepository.Update(flat);
            return flat;
        }

        public async Task<bool> Remove(Flat flat)
        {
            //var books = await _bookService.GetBooksByCategory(category.Id);
            //if (books.Any()) return false;

            await _flatRepository.Remove(flat);
            return true;
        }

       
        public void Dispose()
        {
            _flatRepository?.Dispose();
        }

    }
}
