﻿using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Services
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IInvoiceRepository _invoiceRepository;

        public InvoiceService(IInvoiceRepository invoiceRepository)
        {
            _invoiceRepository = invoiceRepository;

        }

        public async Task<IEnumerable<Invoice>> GetAll()
        {
            return await _invoiceRepository.GetAll();
        }

        public async Task<Invoice> GetById(int id)
        {
            return await _invoiceRepository.GetById(id);
        }

        public async Task<Invoice> Add(Invoice invoice)
        {
            await _invoiceRepository.Add(invoice);
            return invoice;
        }

        public async Task<Invoice> Update(Invoice invoice)
        {
            await _invoiceRepository.Update(invoice);
            return invoice;
        }

        public async Task<bool> Remove(Invoice invoice)
        {
            //var books = await _bookService.GetBooksByCategory(category.Id);
            //if (books.Any()) return false;

            await _invoiceRepository.Remove(invoice);
            return true;
        }


        public void Dispose()
        {
            _invoiceRepository?.Dispose();
        }


        Task<IEnumerable<Invoice>> IInvoiceService.GetInvoiceByUser(int flatId)
        {
            throw new NotImplementedException();
        }

    }
}
