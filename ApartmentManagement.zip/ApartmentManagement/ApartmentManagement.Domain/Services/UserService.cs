﻿using ApartmentManagement.Domain.Interfaces;
using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        
        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
                   }

        public async Task<IEnumerable<User>> GetAll()
        {
            return await _userRepository.GetAll();
        }

        public async Task<User> GetById(int id)
        {
            return await _userRepository.GetById(id);
        }

        public async Task<User> Add(User User)
        {
            if (_userRepository.Search(c => c.UserName == User.UserName).Result.Any())
                return null;

            await _userRepository.Add(User);
            return User;
        }

        public async Task<User> Update(User User)
        {
            if (_userRepository.Search(c => c.UserName == User.UserName && c.Id != User.Id).Result.Any())
                return null;

            await _userRepository.Update(User);
            return User;
        }

        public async Task<bool> Remove(User User)
        {
          
            await _userRepository.Remove(User);
            return true;
        }


        public void Dispose()
        {
            _userRepository?.Dispose();
        }

    }
}