﻿using ApartmentManagement.Domain.Interfaces;
using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPaymentRepository _paymentRepository;
        
        public PaymentService(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        public async Task<IEnumerable<Payment>> GetAll()
        {
            return await _paymentRepository.GetAll();
        }

        public async Task<Payment> GetById(int id)
        {
            return await _paymentRepository.GetById(id);
        }

        public async Task<Payment> Add(Payment payment)
        {
          
            await _paymentRepository.Add(payment);
            return payment;
        }

        public async Task<Payment> Update(Payment payment)
        {
         
            await _paymentRepository.Update(payment);
            return payment;
        }

        public async Task<bool> Remove(Payment payment)
        {
          
            await _paymentRepository.Remove(payment);
            return true;
        }


        public void Dispose()
        {
            _paymentRepository?.Dispose();
        }

        public Task<IEnumerable<Payment>> GetPaymentByFlat(int flatId)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Payment>> GetPaymentByUser(int userId)
        {
            throw new NotImplementedException();
        }
    }
}