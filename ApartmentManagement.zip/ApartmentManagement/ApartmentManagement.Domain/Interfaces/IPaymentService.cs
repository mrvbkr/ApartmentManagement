﻿
using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagement.Domain.Interfaces
{
    public interface IPaymentService:IDisposable
    {
        Task<IEnumerable<Payment>> GetAll();
        Task<Payment> GetById(int id);
        Task<Payment> Add(Payment payment);
        Task<bool> Remove(Payment payment);
        Task<IEnumerable<Payment>> GetPaymentByFlat(int flatId);
        Task<IEnumerable<Payment>> GetPaymentByUser(int userId);

    }
}
