﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagementApp.Domain.Interfaces
{
    public interface IDuesService:IDisposable
    {
        Task<IEnumerable<Dues>> GetAll();
        Task<Dues> Add(Dues dues);
        Task<Dues> GetById(int id);
        Task<Dues> Update(Dues dues);
        Task<bool> Remove(Dues dues);
        Task<IEnumerable<Dues>> GetDuesByUser(int userId);
       
    }
}
