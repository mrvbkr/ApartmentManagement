﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagementApp.Domain.Interfaces
{
    public interface IMessageService:IDisposable
    {
        Task<IEnumerable<Message>> GetAll();
        Task<Message> GetById(int id);
        Task<Message> Add(Message message);
        Task<bool> Remove(Message message);
       
    }
}
