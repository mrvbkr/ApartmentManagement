﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagementApp.Domain.Interfaces
{
    public interface IFlatService : IDisposable
    {
        Task<IEnumerable<Flat>> GetAll();
        Task<Flat> GetById(int id);
        Task<Flat> Add(Flat flat);
        Task<Flat> Update(Flat flat);
        Task<bool> Remove(Flat flat);
    }
}
