﻿using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagementApp.Domain.Interfaces
{
    public interface IInvoiceService:IDisposable
    {
        Task<IEnumerable<Invoice>> GetAll();
        Task<Invoice> Add(Invoice invoice);
        Task<Invoice> GetById(int id);
        Task<Invoice> Update(Invoice invoice);
        Task<bool> Remove(Invoice invoice);
        Task<IEnumerable<Invoice>> GetInvoiceByUser(int userId);

    }
}
