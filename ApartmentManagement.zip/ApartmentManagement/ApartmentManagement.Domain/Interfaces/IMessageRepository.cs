﻿using ApartmentManagement.Domain.Interfaces;
using ApartmentManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentManagementApp.Domain.Interfaces
{
    public interface IMessageRepository:IRepository<Message>
    {
    }
}
