﻿using ApartmentManagement.Domain.Interfaces;
using Braintree;
using Microsoft.AspNetCore.Mvc;
using System;

namespace ApartmentManagement.Controllers
{
    public class UserPaymentController : Controller
    {
    
        private readonly IBraintreeService _braintreeService;

        public UserPaymentController(IBraintreeService braintreeService)
        {
            _braintreeService = braintreeService;
        }
        public IActionResult Index()
        {
            var gateway = _braintreeService.GetGateway();
            var clientToken = gateway.ClientToken.Generate();  
            ViewBag.ClientToken = clientToken;

            return View();
        }

        public IActionResult Create()
        {
            var gateway = _braintreeService.GetGateway();
            var request = new TransactionRequest
            {
                Amount = Convert.ToDecimal("250"),
                               Options = new TransactionOptionsRequest
                {
                    SubmitForSettlement = true
                }
            };

            Result<Transaction> result = gateway.Transaction.Sale(request);

            if (result.IsSuccess())
            {
                return View("Success");
            }
            else
            {
                return View("Failure");
            }
        }
    }
}

