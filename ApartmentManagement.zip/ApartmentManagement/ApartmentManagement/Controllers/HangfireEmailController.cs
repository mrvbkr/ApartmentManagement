﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.IdentityModel.Protocols;
using System.Globalization;
using System.Net.Mail;
using System.Net;
using System.Threading.Tasks;
using System;

namespace ApartmentManagement.Controllers
{
    public class HangfireEmailController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

    //    public async Task<ActionResult> SendEmail()
    //    {
    //        //Email
    //        var message = EMailTemplate("WelcomeEmail");
    //        message = message.Replace("@ViewBag.Name", CultureInfo.CurrentCulture.TextInfo.ToTitleCase("Reza"));
    //        message = message.Replace("@ViewBag.Details", "This is Test Details");
    //        await SendEmailAsync(toEmail, "Test subject", message);
    //        //End Email
    //        return Json(0, JsonRequestBehavior.AllowGet);
    //    }
    //    public string EMailTemplate(string template)
    //    {
    //        string body = System.IO.File.ReadAllText(HostingEnvironment.MapPath("~/Content/template/") + template + ".cshtml");
    //        return body.ToString();
    //    }


    //    public async static Task SendEmailAsync(string email, string subject, string message)
    //    {
    //        try
    //        {

    //            var _email = "fsjesy@gmail.com";
    //            var _epass = ConfigurationManager.AppSettings["EmailPassword"];
    //            var _dispName = "Test Mail";

    //            MailMessage myMessage = new MailMessage();
    //            myMessage.To.Add(email);
    //            myMessage.From = new MailAddress(_email, _dispName);
    //            myMessage.Subject = subject;
    //            myMessage.Body = message;
    //            myMessage.IsBodyHtml = true;


    //            using (SmtpClient smtp = new SmtpClient())
    //            {
    //                smtp.EnableSsl = true;
    //                smtp.Host = "smtp.gmail.com";
    //                smtp.Port = 587;
    //                smtp.UseDefaultCredentials = false;
    //                smtp.Credentials = new NetworkCredential(_email, _epass);
    //                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
    //                smtp.SendCompleted += (s, e) => { smtp.Dispose(); };
    //                await smtp.SendMailAsync(myMessage);
    //            }


    //        }
    //        catch (Exception)
    //        {

    //            throw;
    //        }

    //    }

    //}
}
    
}
