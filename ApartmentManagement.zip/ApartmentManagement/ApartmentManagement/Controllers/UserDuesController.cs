﻿using ApartmentManagement.Domain.Interfaces;
using ApartmentManagement.Domain.Models;
using ApartmentManagement.Domain.Services;
using ApartmentManagementApp.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApartmentManagement.Controllers
{
    public class UserDuesController : Controller
    {
        private readonly IDuesService _duesService;

        public UserDuesController(IDuesService duesService)
        {
            _duesService = duesService;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<Dues> model = await _duesService.GetDuesByUser(1);
            return View(model);
        }
    }
}
