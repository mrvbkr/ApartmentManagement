﻿using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApartmentManagement.Controllers
{
    public class FlatController : Controller
    {
        private readonly IFlatService _flatService;

        public FlatController(IFlatService flatService)
        {
            _flatService = flatService;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<Flat> model = await _flatService.GetAll();
            return View(model);
        }

        public IActionResult New()
        {
            return View();
        }

        public async Task<IActionResult> Add(Flat flat)
        {
            if (!ModelState.IsValid) return BadRequest();

            var categoryResult = await _flatService.Add(flat);

            if (categoryResult == null) return BadRequest();

            return RedirectToAction("index", "Flat");
        }

        public async Task<IActionResult> Update(int id,Flat flat)
        {
            
            if (!ModelState.IsValid) return BadRequest();

            await _flatService.Update(flat);
            return RedirectToAction("index", "Flat");
        }

        public async Task<IActionResult> Remove(int id)
        {
            var flat = await _flatService.GetById(id);
            if (flat == null) return NotFound();

            var result = await _flatService.Remove(flat);

            if (!result) return BadRequest();

            return RedirectToAction("index", "Flat");
        }
    }
}
