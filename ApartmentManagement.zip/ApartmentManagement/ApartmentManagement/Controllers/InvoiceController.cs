﻿using ApartmentManagement.Domain.Models;
using ApartmentManagementApp.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApartmentManagement.Controllers
{
    public class InvoiceController : Controller
    {
        private readonly IInvoiceService _invoiceService;

        public InvoiceController(IInvoiceService invoiceService)
        {
            _invoiceService = invoiceService;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<Invoice> model = await _invoiceService.GetAll();
            return View(model);
        }

        public IActionResult New()
        {
            return View();
        }

        public async Task<IActionResult> Add(Invoice invoice)
        {

            var invoiceResult = await _invoiceService.Add(invoice);

            if (invoiceResult == null) return BadRequest();

            return RedirectToAction("index", "Invoice");
        }

        public async Task<IActionResult> Update(int id, Invoice invoice)
        {

            if (!ModelState.IsValid) return BadRequest();

            await _invoiceService.Update(invoice);

            return Ok();
        }

        public async Task<IActionResult> Remove(int id)
        {
            var invoice = await _invoiceService.GetById(id);
            if (invoice == null) return NotFound();

            var result = await _invoiceService.Remove(invoice);

            if (!result) return BadRequest();

            return RedirectToAction("index", "Invoice");
        }
    }
}
