﻿using Microsoft.AspNetCore.Mvc;

namespace ApartmentManagement.Controllers
{
    public class AdminHome : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
