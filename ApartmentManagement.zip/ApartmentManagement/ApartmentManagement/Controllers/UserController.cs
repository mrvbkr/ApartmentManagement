﻿using ApartmentManagement.Domain.Interfaces;
using ApartmentManagement.Domain.Models;
using ApartmentManagement.Domain.Services;
using ApartmentManagementApp.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApartmentManagement.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<User> model = await _userService.GetAll();
            return View(model);
        }

        public IActionResult New()
        {
            return View();
        }

        public async Task<IActionResult> Add(User user)
        {
            //random bir şifre ataması yapıldı.
            user.Password = Guid.NewGuid().ToString().Substring(0, 4);
            user.Role = "user";
            var userResult = await _userService.Add(user);
           
            if (userResult == null) return BadRequest();

            return RedirectToAction("index", "User");
        }

        public async Task<IActionResult> Update(int id)
        {
            var model = _userService.GetById(id);
            if (model == null) return BadRequest();
            return RedirectToAction("new", "User");
        }

        public async Task<IActionResult> Remove(int id)
        {
            var flat = await _userService.GetById(id);
            if (flat == null) return NotFound();

            var result = await _userService.Remove(flat);

            if (!result) return BadRequest();

            return RedirectToAction("index", "User");
        }
    }
}
