﻿using ApartmentManagement.Domain.Interfaces;
using ApartmentManagement.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using ApartmentManagementApp.Domain.Interfaces;
using ApartmentManagement.Domain.Services;

namespace ApartmentManagement.Controllers
{
    public class DuesController : Controller
    {
        private readonly IDuesService _duesService;

        public DuesController(IDuesService duesService)
        {
            _duesService = duesService;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<Dues> model = await _duesService.GetAll();
            return View(model);
        }

        public IActionResult New()
        {
            return View();
        }

        public async Task<IActionResult> Add(Dues dues)
        {
        
            var userResult = await _duesService.Add(dues);

            if (userResult == null) return BadRequest();

            return RedirectToAction("index", "Dues");
        }

        public async Task<IActionResult> Update(int id, Dues dues)
        {

            if (!ModelState.IsValid) return BadRequest();

            await _duesService.Update(dues);

            return Ok();
        }

        public async Task<IActionResult> Remove(int id)
        {
            var flat = await _duesService.GetById(id);
            if (flat == null) return NotFound();

            var result = await _duesService.Remove(flat);

            if (!result) return BadRequest();

            return RedirectToAction("index", "Dues");
        }
    }
}
