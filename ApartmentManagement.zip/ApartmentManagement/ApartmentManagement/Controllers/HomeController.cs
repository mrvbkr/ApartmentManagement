﻿using ApartmentManagement.Domain.Models;
using ApartmentManagement.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using ApartmentManagement.Domain.Context;

namespace ApartmentManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly AppDbContext _appDbContext;

        public HomeController(ILogger<HomeController> logger, AppDbContext appDbContext)
        {
            _logger = logger;
            _appDbContext = appDbContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> login(LoginViewModel loginViewModel)

        {
            var user = _appDbContext.Users.ToList();

            if (ModelState.IsValid)
            {
                var isUser = _appDbContext.Users.FirstOrDefault(x => x.UserName == loginViewModel.UserName && x.Password == loginViewModel.Password);

                if (isUser != null)
                {
                    List<Claim> userClaims = new List<Claim>();

                    userClaims.Add(new Claim(ClaimTypes.NameIdentifier, isUser.Id.ToString()));
                    userClaims.Add(new Claim(ClaimTypes.Name, isUser.UserName));
                    userClaims.Add(new Claim(ClaimTypes.GivenName, isUser.Name));
                    userClaims.Add(new Claim(ClaimTypes.Surname, isUser.SurName.ToString()));
                    userClaims.Add(new Claim(ClaimTypes.Role, isUser.Role.ToString()));

                    var claimsIdentity = new ClaimsIdentity(userClaims, CookieAuthenticationDefaults.AuthenticationScheme);

                    var authProperties = new AuthenticationProperties
                    {
                        IsPersistent = loginViewModel.IsRememberMe
                    };

                    await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

                    await HttpContext.SignInAsync(
        CookieAuthenticationDefaults.AuthenticationScheme,
        new ClaimsPrincipal(claimsIdentity),
        authProperties);
                    if (isUser.Role == "Admin")
                    {
                        return RedirectToAction("Index", "AdminHome");

                    }
                    else if(isUser.Role == "user")
                    {
                        return RedirectToAction("Index", "UserHome");
                    }
                   
                }
                else
                {
                    ModelState.AddModelError("", "Kullanıcı adı veya şifre yanlış");
                }
            }

            return View(loginViewModel);
        }
    }
}
