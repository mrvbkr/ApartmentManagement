﻿using ApartmentManagement.Domain.Models;
using ApartmentManagement.Domain.Services;
using ApartmentManagementApp.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApartmentManagement.Controllers
{
    public class UserInvoiceController : Controller
    {
        private readonly IInvoiceService _invoiceService;

        public UserInvoiceController(IInvoiceService invoiceService)
        {
            _invoiceService = invoiceService;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<Invoice> model = await _invoiceService.GetInvoiceByUser(1);
            return View(model);
        }
    }
}
