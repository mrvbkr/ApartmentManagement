﻿using ApartmentManagement.Domain.Interfaces;
using ApartmentManagement.Domain.Services;
using ApartmentManagement.Infrastructure.Repositories;
using ApartmentManagementApp.Domain.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace ApartmentManagement.Configuration
{
    public static class DependencyInjectionConfig
    {
        public static IServiceCollection ResolveDependencies(this IServiceCollection services)
        {

            services.AddScoped<IFlatRepository, FlatRepository>();
            services.AddScoped<IFlatService, FlatService>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IDuesRepository, DuesRepository>();
            services.AddScoped<IDuesService, DuesService>();
            services.AddScoped<IInvoiceRepository, InvoiceRepository>();
            services.AddScoped<IInvoiceService, InvoiceService>();
            services.AddScoped<IPaymentRepository, PaymentRepository>();
            services.AddScoped<IPaymentService, PaymentService>();


            return services;
        }
    }
}
